//
//  ProfileFormCell.swift
//  RxSwiftBasics5
//
//  Created by Young Kim on 2018-05-14.
//  Copyright © 2018 Younghwan Kim. All rights reserved.
//

import UIKit

class ProfileFormCell: UITableViewCell {

    @IBOutlet weak var fieldTitleLabel: UILabel!
    @IBOutlet weak var fieldValueLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

}
